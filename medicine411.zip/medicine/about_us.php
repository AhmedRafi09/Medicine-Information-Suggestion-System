<?php
//require 'connection.php';
$title = 'About Us';
include 'header.php';
?>
<div class="container">
	<h1>Medicine Information Management and Suggestion System</h1>
	<p> </p>
</div>


<?php
include 'footer.php';
?>