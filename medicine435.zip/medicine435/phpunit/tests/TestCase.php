<?php
require_once('DB.php');
/**
* 
*/
class TestCse extends \PHPUnit_Framework_TestCase
{
	//TestCase 001
	public function testDBConnection()
	{
		# code...
		$this->assertTrue(checkDBConnection());
	}


	//TestCase 101
	public function testMedInfo_NotEmptyCompany_NotEmptyGenre()
	{
		# code...
		$this->assertEquals(medInfo("Zenith pharmaceuticals ltd.", "Antacids"), 1);
	}


	//TestCase 102
	public function testMedInfo_NotEmptyCompany_EmptyGenre()
	{
		# code...
		$this->assertEquals(medInfo("Drug International Ltd.", ""), 2);
	}


	//TestCase 103
	public function testMedInfo_EmptyCompany_NotEmptyGenre()
	{
		# code...
		$this->assertEquals(medInfo("", "Antacids"), 3);
	}


	//TestCase 104
	public function testMedInfo_EmptyCompany_EmptyGenre()
	{
		# code...
		$this->assertEquals(medInfo("", ""), 'Please Select At Least One Field !!');
	} 


    //TestCase 105
	public function testMedInfo_Company_NotMatch_Genre()
	{
		# code...
		$this->assertEquals(medInfo("Zenith pharmaceuticals ltd.", "Prokinetic drugs"), "No medicine found!");
	}


	//TestCase 201
	public  function testCheckInput_IsNumeric()
	{
		$this->assertEquals(checkNumeric("Osmotic purgatives", "E-LAX", "Syrup", "Edruc Limited", "constipation", "lactulose USP 3.4gm/concentrate oral solution; 1 tsf (5ml)"), '0');
	}

	
	//TestCase 202
	public  function testCheckInput_IsNumeric()
	{
		$this->assertEquals(checkNumeric("Osmotic purgatives", "E-LAX", "4132414", "Edruc Limited", "constipation", "lactulose USP 3.4gm/concentrate oral solution; 1 tsf (5ml)"), '1');
	}


	//TestCase 203
	public  function testCheckInput_IsNumeric()
	{
		$this->assertEquals(checkNumeric("43", "6463", "CCCCCC", "757", "777", "77857"), '1');
	}


	//TestCase 208
	public  function testCheckInput_IsEmpty()
	{
		$this->assertEquals(checkEmpty("AAAA", "BBBB", "CCCC", "DDDD", "EEEE", "FFFF"), '0');
	}


	//TestCase 208
	public  function testCheckInput_IsEmpty()
	{
		$this->assertEquals(checkEmpty("", "", "", "", "", ""), '1');
	}


	//TestCase 2010
	public  function testCheckInput_IsEmpty()
	{
		$this->assertEquals(checkEmpty("AAAA", "", "", "", "", "FFFF"), '1');
	}

	//TestCase 301
	public function testSuggestMedicine()
	{
		$this->assertEquals(suggestMedicine("peptic ulcer"), 3);
	}

	//TestCase 302
	public function testSuggestMedicine()
	{
		$this->assertEquals(suggestMedicine(""), "Please Select a Disease");
	}


}

?>