<?php
include_once "DB.php";
session_start();


$db = new DB();
$db->checkDBConnection();

?>
